package TestClass;


import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.io.IOException;

import static org.junit.Assert.assertTrue;


public class Junit {

    int Numbers;

    public class Numbers {
        public static boolean isOdd(int number) {
            return number % 2 != 0;
        }
    }

    @ParameterizedTest
        @ValueSource(ints = {1, 3, 5, -3, 15, Integer.MAX_VALUE}) // six numbers
        void isOdd_ShouldReturnTrueForOddNumbers(int number) {
            assertTrue(Numbers.isOdd(number));
        }

    
}
