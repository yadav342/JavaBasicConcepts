package TestClass;

import SetupBrowser.BaseTest;
import browserStackPages.HomePage;
import browserStackPages.LoginPage;
import io.qameta.allure.*;
import org.junit.Test;

@Epic("Web Application Regression Testing using JUnit5")
    @Feature("Login Page Tests")
    public class LoginTest extends BaseTest {

        LoginPage objLogin;
        HomePage objDashboardPage;

        @Severity(SeverityLevel.NORMAL)
        @Test
        @Description("Test Description : Verify the title of Login Page")
        @Story("Title of Login Page")
        public void verifyLoginPage() {

            // Create Login Page object
            objLogin = new LoginPage(driver);

            // Verify login page text
            objLogin.verifyPageTitle();
        }

        @Severity(SeverityLevel.BLOCKER)
        @Test
        @Description("Test Description : Login Test with invalid credentials")
        @Story("Unsuccessful Login to Application")
        public void invalidCredentialTest() {

            // Create Login Page object
            objLogin = new LoginPage(driver);
            objLogin.login("test", "test123");
            // Verify login page text
            objLogin.verifyErrorMessage();

        }

    }

