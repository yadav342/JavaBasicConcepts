package TestClass;
import SetupBrowser.BaseTest;
import browserStackPages.HomePage;
import browserStackPages.LoginPage;
import org.junit.jupiter.api.Test;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

@Epic("Web Application Regression Testing using JUnit5")
@Feature("Dashboard Page Tests")
public class HomeTest extends BaseTest {

    LoginPage objLogin;
    HomePage objDashboardPage;

    @Severity(SeverityLevel.BLOCKER)
    @Test
    @Description("Test Description : Verify title of Dashboard page")
    @Story("Title of Dashboard Page")
    public void dashboardTitleTest() {

        objLogin = new LoginPage(driver);

        // login to application
        objLogin.login("Admin", "admin123");

        // go the dashboard page
        objDashboardPage = new HomePage(driver);

        objDashboardPage.verifyDashboardPageTitle();

    }

    @Severity(SeverityLevel.BLOCKER)
    @Test
    @Description("Test Description : Verify Assign Leave Option in Quick Link Menu")
    @Story("Validation of Assign Leave Option")
    public void assignLeaveOptionTest() {

        objLogin = new LoginPage(driver);

        // login to application
        objLogin.login("Admin", "admin123");

        // go the dashboard page
        objDashboardPage = new HomePage(driver);

        objDashboardPage.verifyAssignLeaveOption();

    }

    @Severity(SeverityLevel.BLOCKER)
    @Test
    @Description("Test Description : Verify Apply Leave Option in Quick Link Menu")
    @Story("Validation of Apply Leave Option")
    public void applyLeaveOptionTest() {

        objLogin = new LoginPage(driver);

        // login to application
        objLogin.login("Admin", "admin123");

        // go the dashboard page
        objDashboardPage = new HomePage(driver);

        objDashboardPage.verifyApplyLeaveOption();

    }

    @Severity(SeverityLevel.BLOCKER)
    @Test
    @Description("Test Description : Verify Leave List Option in Quick Link Menu")
    @Story("Validation of Leave List Option")
    public void leaveListOptionTest() {

        objLogin = new LoginPage(driver);

        // login to application
        objLogin.login("Admin", "admin123");

        // go the dashboard page
        objDashboardPage = new HomePage(driver);

        objDashboardPage.verifyLeaveListOption();

    }

    @Severity(SeverityLevel.BLOCKER)
    @Test
    @Description("Test Description : Verify Timesheets Option in Quick Link Menu")
    @Story("Validation of Timesheets Option")
    public void timesheetsOptionTest() {

        objLogin = new LoginPage(driver);

        // login to application
        objLogin.login("Admin", "admin123");

        // go the dashboard page
        objDashboardPage = new HomePage(driver);

        objDashboardPage.verifytimesheetsOption();
                //verifyTimesheetsOption();

    }

}