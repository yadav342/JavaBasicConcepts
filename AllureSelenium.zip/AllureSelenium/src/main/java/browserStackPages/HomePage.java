package browserStackPages;

import io.qameta.allure.Step;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

        WebDriver driver;

        By dashboardPageTitle = By.id("welcome");

        By assignLeaveOption = By.cssSelector(
                "#dashboard-quick-launch-panel-menu_holder > table > tbody > tr > td:nth-child(1) > div > a > span");

        By leaveListOption = By.cssSelector(
                "#dashboard-quick-launch-panel-menu_holder > table > tbody > tr > td:nth-child(2) > div > a > span");

        By timesheetsOption = By.cssSelector(
                "#dashboard-quick-launch-panel-menu_holder > table > tbody > tr > td:nth-child(3) > div > a > span");

        By applyLeaveOption = By.cssSelector(
                "#dashboard-quick-launch-panel-menu_holder > table > tbody > tr > td:nth-child(4) > div > a > span");

        public HomePage(WebDriver driver) {
            this.driver = driver;

        }

        @Step("Verify title of Dashboard page")
        public void verifyDashboardPageTitle() {
            String DashboardPageTitle = driver.findElement(dashboardPageTitle).getText();
            Assert.assertTrue(DashboardPageTitle.contains("Welcome"));
        }

        @Step("Verify Assign Leave Quick Launch Options on Dashboard page")
        public void verifyAssignLeaveOption() {
            String QuickLaunchOptions = driver.findElement(assignLeaveOption).getText();
            Assert.assertTrue(QuickLaunchOptions.contains("Assign Leave"));
        }

        @Step("Verify Leave List Quick Launch Options on Dashboard page")
        public void verifyLeaveListOption() {
            String LeaveListQuickLaunchOption = driver.findElement(leaveListOption).getText();
            Assert.assertTrue(LeaveListQuickLaunchOption.contains("Leave List"));
        }

        @Step("Verify Assign Leave Quick Launch Options on Dashboard page")
        public void verifytimesheetsOption() {
            String timesheetsOptionQuickLaunchOption = driver.findElement(timesheetsOption).getText();
            Assert.assertTrue(timesheetsOptionQuickLaunchOption.contains("Timesheets"));
        }

        @Step("Verify Leave List Quick Launch Options on Dashboard page")
        public void verifyApplyLeaveOption() {
            String applyLeaveQuickLaunchOptions = driver.findElement(applyLeaveOption).getText();
            Assert.assertTrue(applyLeaveQuickLaunchOptions.contains("Apply Leave"));
        }

    }
