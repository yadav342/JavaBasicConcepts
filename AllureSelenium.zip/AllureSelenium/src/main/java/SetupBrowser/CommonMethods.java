package SetupBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class CommonMethods {

    public static  WebDriver driver;

    public static void SetUp(){
        WebDriverManager.chromedriver().setup();
     ChromeOptions options = new ChromeOptions();
       options.addArguments("--incognito");
      System.setProperty("chromeoptions.args", "--incognito");
       driver = new ChromeDriver(options);
       driver.manage().window().maximize();

    }

    public static void GetURL() throws IOException {
        Properties prop = new Properties();
        try{
            FileInputStream path = new FileInputStream("src/main/java/SetupBrowser/TestData.properties");
            prop.load(path);}
        catch (Exception e){
            System.out.println("TestData is coming from Enum Class");        }
       String url = String.valueOf(prop.get("URL")) ;
       String newURL =  common.URL.getValue();
          driver.get(url);
    }

//    public static String Firstname(){
//        Properties prop = new Properties();
//        try{
//            FileInputStream path = new FileInputStream("src/main/java/TestData.properties");
//            prop.load(path);
//        }
//        catch (Exception e){
//            // System.out.println("TestData");
//            e.printStackTrace();
//
//        }
//        String firstname = String.valueOf(prop.get("FirstName")) ;
//      //  String newURL =  common.URL.getValue();
//        //driver.get(firstname);
//        return firstname;
//
//    }
//
//
//    public static void ROBOT() throws AWTException {
//
//        Robot robo = new Robot();
//
//        robo.keyPress(KeyEvent.VK_E);
//
//    }



}
