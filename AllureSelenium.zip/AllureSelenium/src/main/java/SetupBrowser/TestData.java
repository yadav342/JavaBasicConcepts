package SetupBrowser;

public enum TestData {
}
