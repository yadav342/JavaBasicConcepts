package SetupBrowser;

public enum common {

    URL("https://www.facebook.com"),
    Abc("https://www.facebook.com"),
    syc("https://www.facebook.com"),
    xys("https://www.facebook.com"),
    fdt("https://www.facebook.com"),
    ss("https://www.facebook.com");


    private String value;
    common(String url){
        value = url;
    }

    public String getValue() {
        return value;
    }
}

class GetProperty{

    public static void main(String args[]){
        common.URL.getValue();
    }



}
