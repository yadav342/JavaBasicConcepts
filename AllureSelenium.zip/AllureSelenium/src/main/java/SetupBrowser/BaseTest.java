package SetupBrowser;

import browserStackPages.HomePage;
import browserStackPages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.qameta.allure.Step;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;


public class BaseTest {

    public static WebDriver driver;
    LoginPage objLogin;
    HomePage objDashboardPage;

    @Step("Start the application")
    @BeforeEach
    public void setUp() {
      WebDriverManager.chromedriver().setup();
      driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://opensource-demo.orangehrmlive.com/");
        String expectedPageTitle = "Google";
        Assert.assertTrue(driver.getTitle().contains(expectedPageTitle));
        }

        @Step("Stop the application")
        @AfterEach
        public void close() {
            driver.close();
        }
    }




