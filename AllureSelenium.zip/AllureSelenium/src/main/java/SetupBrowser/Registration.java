package SetupBrowser;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class Registration extends CommonMethods {
    WebDriver driver;

    By FirstName = By.xpath("//input[@name='firstName']");

    public Registration(WebDriver driver) {
        this.driver = driver;
    }

    @Test
    public void Register() throws IOException, InterruptedException, AWTException {

        CommonMethods.GetURL();

        Thread.sleep(10000);
      // String Firstname = CommonMethods.Firstname();

        Robot robo = new Robot();
        // System.out.println(Firstname);
       // CommonMethods.driver.findElement(By.xpath(CommonMethods.Firstname())).sendKeys("Raman");
        CommonMethods.driver.findElement(By.xpath("//input[@name='firstName']")).click();
        robo.keyPress(KeyEvent.VK_R);
        robo.keyPress(KeyEvent.VK_F);
        robo.keyPress(KeyEvent.VK_G);
        robo.keyPress(KeyEvent.VK_H);
        robo.keyPress(KeyEvent.VK_CONTROL);
        robo.keyPress(KeyEvent.VK_C);

        Actions action = new Actions(CommonMethods.driver);


//        CommonMethods.driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("Kumar");
//        CommonMethods.driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("123456");
//        CommonMethods.driver.findElement((By.xpath("//input[@id='userName']"))).sendKeys("raman.kumar@gmail.com");
//        Select sc = new Select(CommonMethods.driver.findElement(By.xpath("//select[@name='country']")));



    }
//
//    @Test
//    public void signIn() throws IOException {
//
//        CommonMethods.SetUp();
//        CommonMethods.GetURL();
//
//
//    }

}
