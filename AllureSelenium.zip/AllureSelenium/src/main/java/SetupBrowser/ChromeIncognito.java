package SetupBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class ChromeIncognito {
    @Test
    public void SendInput() throws InterruptedException {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        //  System.setProperty("webdriver.chrome.driver","D:\\New_folder\\chromedriver_new.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
}}
