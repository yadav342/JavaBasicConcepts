package SetupBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LaunchChrome {
    public static WebDriver driver;
       public void Registration() throws InterruptedException {

//        WebDriverManager.chromedriver().setup();
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--incognito");
//        //System.setProperty("chromeoptions.args", "--incognito");
//
//        driver = new ChromeDriver(options);
//        driver.manage().window().maximize();

        driver.get("http://demo.guru99.com/test/newtours/register_sucess.php");
//   driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys("Raman");
//
//        driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys("Kumar");
//
//       driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("123456");
//       driver.findElement((By.xpath("//input[@id='userName']"))).sendKeys("raman.kumar@gmail.com");
//       Select sc = new Select(driver.findElement(By.xpath("//select[@name='country']")));
        Thread.sleep(15000);
//       //sc.selectByIndex(1);
//       sc.selectByValue("AUSTRALIA");
//       driver.findElement(By.xpath("//input[@id='email']")).sendKeys("raman12");
//        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("raman12");
//        driver.findElement(By.xpath("//input[@name='confirmPassword']")).sendKeys("raman12");
//        driver.findElement(By.xpath("//input[@name='submit']")).click();

        String Actual = driver.findElement(By.cssSelector("p:nth-child(3) font:nth-child(1) b:nth-child(1)")).getText();

        System.out.println(Actual);

        String expected = "Note: Your user name is .";

        Assert.assertTrue(Actual.contains(Actual));

        Assert.assertTrue("Registration", Actual.contains(Actual));


    }



    public void SignIN() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        //System.setProperty("chromeoptions.args", "--incognito");
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get("http://demo.guru99.com/test/newtours/login.php");
        driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("raman12");
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("raman12");
        driver.findElement(By.xpath("//input[@name='submit']")).click();
       String actual = driver.findElement(By.cssSelector("tbody tr td h3")).getText();
       String expected = "abc";
      if(actual.contains(expected)){

           Assert.assertTrue("Sign In", actual.contains(expected));
           System.out.println("Test Case Passed");
      }else{
        System.out.println("Test Case Failed");
 }

    }


}

