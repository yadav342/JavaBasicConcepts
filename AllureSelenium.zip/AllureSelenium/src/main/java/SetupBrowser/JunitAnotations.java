package SetupBrowser;

import org.junit.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;

public class JunitAnotations {

@BeforeEach
  public void BeforeTestAnotation(TestInfo testInfo){
    String callingTest = testInfo.getTestMethod().get().getName();
    System.out.println(callingTest);
    System.out.println("This is @Before Class Test Annotation");
  }

    @Test
    public void TestAnotation(){

        System.out.println("This is @Test Annotation");
    }



    @Test
    public void TestAnotation2(){

        System.out.println("This is @Test 2 Annotation");
    }





}
