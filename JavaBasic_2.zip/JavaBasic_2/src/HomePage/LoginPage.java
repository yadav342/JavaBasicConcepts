package HomePage;

import java.util.*;

public class LoginPage {

    public static void main(String arg[])
    {

        System.out.println("Take Input from the user");
        Scanner obj = new Scanner(System.in);
        String name = obj.nextLine();

        System.out.println("Print the value from the user");

        System.out.println(name);




    }



}


 // user defined packages
// built in packages - java API