package HomePage;

import java.io.File;

public class Registration {

 public static void main(String arg[])
 {

     File prop = new File("src/a.properties");

    String name = prop.getName();



     System.out.println(name);




 }
}
