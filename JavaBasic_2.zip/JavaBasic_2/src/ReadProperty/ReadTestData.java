package ReadProperty;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class ReadTestData {
    public static void main(String args[]) throws IOException {
        Properties prop = new Properties();

//Scanner sc = new Scanner(System.in);
try {
    FileInputStream path = new FileInputStream("src/ReadProperty/TestData.properties");
    prop.load(path);
    System.out.println(prop.get("FirstName"));

    System.out.println("this is GetPropertyMethod==="+prop.getProperty("FirstName"));

    System.out.println(prop.get("Lastname"));
    System.out.println(prop.get("Address"));
}catch (Exception e){
    System.out.println("File Not Found");


                    }
    }

    }


