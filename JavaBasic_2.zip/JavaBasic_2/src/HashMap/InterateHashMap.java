package HashMap;
import java.util.HashMap;
import java.util.Map;
public class InterateHashMap {


        public static void main(String[] args)
        {
            // initialize a HashMap

        Map<Integer, String> map = new HashMap<>();
            // Add elements using put method
            map.put(1,"vishal");
            map.put(2,"sachin");
            map.put(3,"vaibhav");

            System.out.println(map);
            System.out.println("******************");
            // Iterate the map using
            // for-each loop
            for (Map.Entry<Integer, String> e1 : map.entrySet())
            {

                System.out.println("Key: " + e1.getKey()
                        + " Value: " + e1.getValue());

            String s =e1.getValue();
            if(e1.getValue()=="Vikram")
                {
                    System.out.println("Data Matched");
                }else {
                System.out.println("Data not Matched");
            }

        }}
    }


