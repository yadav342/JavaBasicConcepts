package HashMap;
import java.util.*;
public class AddValue {
        public static void main(String args[])
        {
             //int a = 1;
            // HashMap< Key, Value> vara\iable name = new HashMap<>();
            HashMap<String, String> hm1 = new HashMap<>();
          // ArrayList<Integer> list = new ArrayList<>();
          // list.add(2);
           hm1.put("Ab","Ram");
           hm1.put("CD","Shyam");
           hm1.put("FG","Radkha");
            hm1.put("HI","Rani");
            System.out.println(hm1);
//             hm1.replace(3,"Ravi");
//          hm1.remove(3);
//           System.out.println(hm1);



            // Initialization of a HashMap
            // using Generics
//            HashMap<Integer, String> hm2
//                    = new HashMap<Integer, String>();
//
//            // Add Elements using put method
//            hm1.put(1, "Abc");
//            hm1.put(2, "Cdc");
//            hm1.put(3, "Xyz");
//
//            hm2.put(1, "Amn");
//            hm2.put(2, "ravi");
//            hm2.put(3, "Sun");
//
//
//
//            System.out.println("Mappings of HashMap hm1 are : "
//                    + hm1);
//            System.out.println("Mapping of HashMap hm2 are : "
//                    + hm2);
        }
    }


