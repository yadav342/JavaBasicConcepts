package ProtectedAccess;

public class InsideThePackage {

    public int rollNo = 12345;


}
