package ProtectedAccess;

public class SecondInsidePackage {



    public static void main(String args[]){

        InsideThePackage obj1 = new InsideThePackage();

       int OutPut =  obj1.rollNo;

       System.out.println("Inside the Package"+OutPut);
    }


}

