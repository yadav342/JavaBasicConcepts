package JavaConditionalBlock;

public class whileAndDowhileClass {

    public static void main(String args[]){
        int i=10;
//        while(i>=1){
//            System.out.println(i);
//            i--;
//        }


        // do while
        do{
            System.out.println(i);
            i--;
        }while(i>11);
    }
    }

