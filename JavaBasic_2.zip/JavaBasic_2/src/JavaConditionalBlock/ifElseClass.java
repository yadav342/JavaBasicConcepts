package JavaConditionalBlock;

public class ifElseClass {


    public static void main(String arg[])
    {
       int num = 6;    // " = " Assignment operator
        System.out.println("*********************************");

     //WebElement title = driver.findElement(By.ID("xxx"));

        if(num==9)     // comparison operator    //    ispresent();
        {
            System.out.println("Title is Present");
        }
        else{
            System.out.println("Title is not present");
        }
        System.out.println("*********************************");
    }
}
