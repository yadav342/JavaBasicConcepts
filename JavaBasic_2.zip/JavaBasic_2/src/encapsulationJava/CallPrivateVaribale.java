package encapsulationJava;

public class CallPrivateVaribale {

    public static void main(String arg[]) {

        Encapsulation ob = new Encapsulation();

        ob.setURL("www.google.com");

    }
}
