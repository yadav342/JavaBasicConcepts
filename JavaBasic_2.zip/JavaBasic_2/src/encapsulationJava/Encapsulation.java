package encapsulationJava;

public class Encapsulation {

    private String URL;
    private String LoginPage;


    public void setURL(String URL) {
        String url = URL;
        System.out.println(url);
    }
}

