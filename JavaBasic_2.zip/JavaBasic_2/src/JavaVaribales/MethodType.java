package JavaVaribales;

public class MethodType {


    public static int Sum(int a, int b){
         int sum= a+b;
        return sum;

    }
    public static void main(String args[]){

         int Cal=  MethodType.Sum(12,12);

         System.out.println(Cal);


    }



}
