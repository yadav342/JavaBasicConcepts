package JavaVaribales;

import javax.swing.*;

public class SwitchTStatement {

    public static void main(String args[]) {

      int num = 10;

        switch (num)
        {

            case 1:
                System.out.println("This is one");
            case 2:
                System.out.println("This is Second");
               break;
            case 4:
                System.out.println("This is Three");

            default:
                System.out.println("This is default Case");






        }

        System.out.println("Out of the Switch Block");

    }}

