package JavaVaribales;

public class DataType {

   // data types

    static int i =9;
    static char ch ='a';
    static String name = "1324Vikram" ;



    public static void main(String args[]) {

        System.out.println("Integer data type+----" +i);

        System.out.println("Char data type+ ----" +ch);

        System.out.println("String data type+-----" +name);


    }




}
