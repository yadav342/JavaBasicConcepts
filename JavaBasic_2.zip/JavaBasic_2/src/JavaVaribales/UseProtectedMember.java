package JavaVaribales;

import ProtectedAccess.InsideThePackage;
import encapsulationJava.Encapsulation;

public class UseProtectedMember{


    public static void main(String args[]){

        Encapsulation obj1 = new Encapsulation();


    }
}
