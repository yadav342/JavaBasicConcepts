package EnumPackage;

public enum Property {
    FIRSTNAME("Vikram"),
    LASTNAME("Yadav");

    private String value;
    Property(String Val){
        value = Val;
    }

    public String getValue() {
        return value;
    }
}

class GetProperty{

    public static void main(String args[]){

        Property.FIRSTNAME.getValue();
    }
}
