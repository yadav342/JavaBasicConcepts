package EnumPackage;
public enum SampleEnum {

    SIGN_CREATE("Aman"),
    SIGN_CREATE_BONUS("Suman"),
    HOME_SCREEN("Sunny"),
    REGISTER_SCREEN("Ankit");

    private final String value;

    SampleEnum(String newValue) {
        value = newValue;
    }
    public String getValue() { return value; }

}
class Demo{

    public static void main(String args[]){

      System.out.println(SampleEnum.SIGN_CREATE.getValue());
        System.out.println(SampleEnum.HOME_SCREEN.getValue());

    }
}


