package EnumPackage;

public enum ReadProty {

    URL("jhhddgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggjdhdgdgdfdfds"),
    LASTNAME("Yadav");

    private final String Value;

    ReadProty(String appURL){
        Value = appURL;
    }

    @Override
    public String toString() {
        return Value;
    }
}
class Propertyof{
    public static void main(String args[]){
       String name = ReadProty.URL.toString();
        System.out.println(name);

    }
}