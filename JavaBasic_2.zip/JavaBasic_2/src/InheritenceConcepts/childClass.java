package InheritenceConcepts;

import Interface.AnimalMainClass;

public class childClass extends ParentClass  {

    private String modelName = "Mustang";

    public static void main(String[] args) {
        childClass myFastCar = new childClass();

      
        myFastCar.honk();

        AnimalMainClass obj2 = new AnimalMainClass();


       // System.out.println(p.brand + " " + myFastCar.modelName);
    }
}
