package InheritenceConcepts;

import Constructor.*;

public class ParentClass {

    protected String brand = "Ford";
    public void honk() {
        System.out.println("Tuut, tuut!");
    }
}
