package JavaMethods;

public class A {

    // public , protected , private , default

    static  int b = 3;


    static int Sum( int a, int b){     // Sum method
        int ABC;
             ABC = a+b;
        return ABC;
    }

    float Sum( Float a, int b){

        return 0 ;
    }

        public  int Mul( int x, int y){          // Multiplication method
        int multiply;
        multiply = x*y;
        return multiply;
    }
    public static String Person(String name){       // String type method

        return name;

    }

}
