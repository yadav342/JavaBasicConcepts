package JavaMethods;

public class B{




    public static void main(String args[]){

    //int SumOftwonumber = A.Sum(2,5);

       //System.out.println("Sum of two Number -: " +SUMOFNUM);

        A obj = new A();




//       A.Sum(1,2);   //3
//
//        System.out.println(SUMOFnumber);
//        System.out.println(Cal);
//
//        System.out.println( A.Person("Vikram"));   // Vikram


    }

    }


