import java.io.IOException;

public class Junit {
    public static void main(String args[]) throws IOException {

//        @ParameterizedTest
//        @ValueSource(ints = {1, 3, 5, -3, 15, Integer.MAX_VALUE}) // six numbers
////        void isOdd_ShouldReturnTrueForOddNumbers(int number) {
//            assertTrue(Numbers.isOdd(number));
//        }

    }
    }



