package Constructor;

public class Person{

    Person(){

       // int A = a;

        //System.out.println("This is method");
    }

//    Seleium/java
//    CI/CD - jenkins
//    GitHUB
//    Container


   static void  City(){

        System.out.println("This is Delhi");
    }




}
