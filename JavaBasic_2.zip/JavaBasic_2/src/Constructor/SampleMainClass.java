package Constructor;

public class SampleMainClass {


    public static void main(String args[]){

//        Person Vikram = new Person();
//
//        Person Sudhakar = new Person();




    }
}
