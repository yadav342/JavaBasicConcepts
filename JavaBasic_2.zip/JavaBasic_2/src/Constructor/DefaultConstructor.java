package Constructor;

import JavaMethods.D;

public class DefaultConstructor {


      static public int methodname(){

           return 0;
       }

       DefaultConstructor(String a, int b){


       }

        public static void main(String args[]) {
            DefaultConstructor ob=    new DefaultConstructor("b",9);
            //DefaultConstructor







            // DefaultConstructor obj1 = new DefaultConstructor();
        }
    }

