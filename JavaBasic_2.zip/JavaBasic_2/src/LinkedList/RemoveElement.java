package LinkedList;

import java.util.LinkedList;

public class RemoveElement {
        public static void main(String args[])
        {
            LinkedList<String> ll = new LinkedList<>();

            ll.add("Aman");
            ll.add("Rekha");
            ll.add(1, "Sunny");

            System.out.println(
                    "Initial LinkedList " + ll);

            ll.remove(1);

            System.out.println(
                    "After the Index Removal " + ll);

            ll.remove("Ravi");

            System.out.println(
                    "After the Object Removal " + ll);
        }
    }


