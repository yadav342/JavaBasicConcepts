package LinkedList;
import java.util.*;

public class AddElement {

    public static void main(String args[])

           // java,selenium, mobile automation, postman, jenkins,,   List

    {
        LinkedList<String> list = new LinkedList<>();
        list.add("vikram");
        list.add("Ravi");
        list.add("Sudhakar");
        list.add("Sonu");

        for(int i=0; i< list.size();i++){

            System.out.println(list.get(i));

    }


//        ll.add("vik");
//        ll.add("abi");
//        ll.add(1, "Sunny");
//
//      update element
//        ll.set(0, "Ajay");
//
//        System.out.println(ll);
    }
}