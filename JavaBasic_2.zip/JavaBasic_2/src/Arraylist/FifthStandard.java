package Arraylist;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class FifthStandard {

    public static void main(String args[]) {

        int a[] = new int[8];

        int i[] = new int[1000];
        i[0] =1;
        a[0] = 1;
        a[1] = 2;
        a[2] = 5;
        a[3] = 7;
        a[4] = 9;
        a[5] = 67;
        a[6] = 98;
        a[7] = 100;

        System.out.println(a);
//        int size = a.length;
//        for(int i=0; i<=size-1;i++){
//
//            System.out.println(a[i]);
//        }

       // System.out.println("Size of Array A= "+size);

//
//
//
//        ArrayList<String> list =new ArrayList<String>();//-->  size
//
//        // ArrayList<WebElement> element = new ArrayList<WebElement>();
//
//        //String title = element.get.Value();
//
//        list.add("Aman");   // 0
//        list.add("Ankit");   // 1
//        list.add("Abhi");
//        list.add("Anamika");
//      // int size ;
//      int size= list.size();
//       //String name = list.get(3);
//        //System.out.println("Value at the Index Zero ="+name);
////       System.out.println("Size of Class 5th ="+size);
//
//        for (String var : list)
//        {
//           System.out.println(var);
//        }
////
//        System.out.println("This is normal for loop output");
//       for(int i=0; i<size;i++){
////
//           System.out.println(list.get(i));
////
//       }

   }

}
