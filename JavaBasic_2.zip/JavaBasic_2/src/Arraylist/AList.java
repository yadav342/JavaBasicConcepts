package Arraylist;

import java.util.*;

public class AList {
    public static void main(String args[])
    {
        List<String> Student =new LinkedList<>();
        List<String> Name =new ArrayList<>();
        Student.add("Ram");  // 0
        Student.add("Naresh");   // 1
        Student.add("Ankit");   // 2
        Student.add("Suman");   // 3
        Student.add("Anamika");    // 4
        Student.set(3,"Abhi");

        System.out.println("Stdent List"+ Student);        //console("");

        for (String i : Student)
    {
        System.out.println(i);
    }

        System.out.println("++++++++Normal For Loop OutPut++++++++");

        for(int i=0;i<Student.size();i++)
        {
            System.out.println(Student.get(i));
        }
//
//        for( initilization; condition; increment){
//            ...........
       //     ...........
//        }\



       // ob.remove(4);

      //  System.out.println("Index of ="+ Student.indexOf("Suman"));

    }
}
