package Arraylist;

public class forEach {




//    for (type var : array)
//    {
//        statements using var;
//    }
}
