package Interface;

public class PersonChild extends Person {

    @Override
    public void color() {

    }



    public static void main(String args[]){

        Person obj = new PersonChild();

        obj.Name();


    }
}
