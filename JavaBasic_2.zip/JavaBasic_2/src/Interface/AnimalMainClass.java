package Interface;

public class AnimalMainClass {

    protected String AccountName = "Vikram";

//    @Override
//    void sleep() {
//
//    }
//
//    public static void main(String args[]){
//
//        Animal ob = new AnimalMainClass() ;
//
//        ob.voice();
    }


