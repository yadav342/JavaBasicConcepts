package Interface;

public interface RBI {

    public void depoist();

    public void withdrow();


}
