package Interface;

public class ICICI extends AnimalMainClass  {


//
    //@Override
    public void depoist() {

        System.out.println("This is implemented Voice Method");
    };
    public void withdrow(){

        System.out.println("This is implemented run Method");

    };


    public static void main(String args[]){

        ICICI ob = new ICICI();
        String nsme = ob.AccountName;

        AnimalMainClass obj = new AnimalMainClass();

        String n = obj.AccountName;


    }

}
