package Interface;

public abstract class Person {

    abstract public  void color();

    public void Name(){

        System.out.println("This is normal method");

    };


}
